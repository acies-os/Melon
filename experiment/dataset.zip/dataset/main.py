import shutil

for i in range(201, 301):
    shutil.copy('1.png', '{}.png'.format(i))
with open('train.txt', 'a+') as f:
    for i in range(201, 301):
        f.write("{}.png 1\n".format(i))